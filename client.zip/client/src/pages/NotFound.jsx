import React from 'react'

const NotFound = () => {
  return (
    <div>
      <h1>notdound</h1>
    </div>
  )
}

export default NotFound
