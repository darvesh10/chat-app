import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const Chat = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const chatPartner = {
    name: 'Mike',
    pic: '👦',
  };

  const [messages, setMessages] = useState([
    { from: 'Mike', text: 'Hey bro!' },
    { from: 'You', text: 'Hello!' },
    { from: 'Mike', text: 'How are you? 😊' },
  ]);

  const [media, setMedia] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [newMedia, setNewMedia] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);

  const handleSendMessage = () => {
    if (newMessage.trim() !== '') {
      setMessages([...messages, { from: 'You', text: newMessage }]);
      setNewMessage('');
    }
    if (newMedia) {
      setMessages([...messages, { from: 'You', image: newMedia }]);
      setMedia(prev => [...prev, newMedia]);
      setNewMedia(null);
    }
  };

  const handleMediaChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const fileURL = URL.createObjectURL(file);
      setNewMedia(fileURL);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-100 to-purple-200 font-sans">
      <Navbar />

      <div className="flex items-center justify-between px-6 py-4 bg-white shadow">
        <div className="flex items-center space-x-3">
          <span className="text-3xl">{chatPartner.pic}</span>
          <h2 className="text-lg font-bold text-indigo-700">{chatPartner.name}</h2>
        </div>
        <button onClick={() => navigate(-1)} className="text-indigo-600 hover:underline">🔙 Back</button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 bg-white/80">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`max-w-xs px-4 py-2 rounded-2xl mb-3 shadow ${msg.from === 'You' ? 'bg-indigo-100 ml-auto text-right' : 'bg-gray-100 mr-auto text-left'}`}
          >
            <p className="font-medium">{msg.from === 'You' ? 'You' : msg.from}</p>
            {msg.text && <p>{msg.text}</p>}
            {msg.image && (
              <img
                src={msg.image}
                alt="Shared"
                className="mt-2 rounded-lg cursor-pointer"
                onClick={() => setPreviewImage(msg.image)}
              />
            )}
          </div>
        ))}

        {media.length > 0 && (
          <div className="border-t pt-4 mt-4">
            <h3 className="text-sm font-semibold text-gray-500 mb-2">Media Shared:</h3>
            <div className="flex flex-col space-y-3">
              {media.map((file, idx) => (
                <img
                  key={idx}
                  src={file}
                  alt="Media"
                  className="h-24 w-auto rounded-lg cursor-pointer shadow"
                  onClick={() => setPreviewImage(file)}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center gap-3 px-6 py-4 bg-white border-t border-gray-300">
        <span className="text-2xl cursor-pointer">😊</span>
        <label>
          <span className="text-2xl cursor-pointer">📎</span>
          <input type="file" onChange={handleMediaChange} className="hidden" />
        </label>
        <input
          type="text"
          placeholder="Type a message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-indigo-400"
        />
        <button
          onClick={handleSendMessage}
          className="bg-indigo-600 text-white rounded-lg px-4 py-2 hover:bg-indigo-700 shadow"
        >
          ⬆️
        </button>
      </div>

      <Footer />

      {previewImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50"
          onClick={() => setPreviewImage(null)}
        >
          <img src={previewImage} alt="Preview" className="max-w-full max-h-full rounded-lg shadow-lg" />
        </div>
      )}
    </div>
  );
};

export default Chat;


